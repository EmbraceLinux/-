#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<pthread.h>
#include"network.h"

void get_ifconfig(in_addr_t* ip,in_addr_t* broad,in_addr_t* mask)
{
	system("ifconfig > /tmp/ifconfig.txt");
	int fd=open("/tmp/ifconfig.txt",O_RDONLY);
	if(0>fd)
	{
		perror("open");
	}
	char buf[1024]={};
	
	read(fd,buf,sizeof(buf));
	close(fd);
	//把字符串的ip地址转换成网络字节序
	char* str = strstr(buf,"地址:")+7;
	*ip = inet_addr(str);
	
	str=strstr(str,":")+1;
	*broad = inet_addr(str);
	
	str=strstr(str,":")+1;
	*mask = inet_addr(str);
}

void* find_server(void* arg)
{
	char* ip=inet_ntoa(((struct sockaddr_in*)arg)->sin_addr);
	printf("%s\n",ip);
	Network* nw=open_network('c',SOCK_STREAM,ip,6677);
	if(NULL!=nw)
	{
		printf("%s\n",inet_ntoa(nw->addr.sin_addr));
	}
}

int main()
{
	in_addr_t ip,broad,mask;
	get_ifconfig(&ip,&broad,&mask);
	//printf("%u %u %u",htonl(ip),htonl(broad),htonl(mask));
	//把ip地址从网络字节序转化成本地字节系，为了遍历
	uint32_t min=ntohl(ip)&ntohl(mask)+1,max=ntohl(broad);
	for(uint32_t ip=min;ip<max;ip++)
	{
		//addr.sin_addr.s_addr=htonl(ip);
		//printf("%s\n",inet_ntoa(addr.sin_addr));
		pthread_t pid;
		struct sockaddr_in addr;
		addr.sin_addr.s_addr=htonl(ip);
		pthread_create(&pid,NULL,find_server,&addr);
		usleep(100);
	}
	sleep(3);
}
