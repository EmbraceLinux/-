#include "network.h"
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>


//创建网络连接
Network* open_network(char c_or_s,int type,char* ip,uint16_t port)
{
	//在堆上创建Network结构
	Network* nw=malloc(sizeof(Network));
	if(NULL==nw)
	{
		perror("network malloc");
		return NULL;
	}
	nw->fd = socket(AF_INET,type,0);
	if(0>nw->fd)
	{
		perror("network socket");
		free(nw);
		return NULL;
	}

	//准备通信地址
	nw->addr.sin_family = AF_INET;
	nw->addr.sin_port = htons(port);
	nw->addr.sin_addr.s_addr = inet_addr(ip);
	nw->len = sizeof(nw->addr);
	nw->type = type;

	if('s' == c_or_s)
	{
		if(bind(nw->fd,(SP)&nw->addr,nw->len))
		{
			perror("network bind");
			free(nw);
			return NULL;
		}
		if(SOCK_STREAM == type && listen(nw->fd,50))
		{
			perror("network listen");
			free(nw);
			return NULL;
		}
	}
	else if('c'==c_or_s && type==SOCK_STREAM)
	{
		if(connect(nw->fd,(SP)&nw->addr,nw->len))
		{
			perror("network connect");
			free(nw);
			return NULL;
		}
	}
	return nw;
}

//TCP的server专用
Network* accept_network(Network* nw)
{
	if(SOCK_STREAM==nw->type)
	{
		printf("network accept type error");
		return NULL;
	}
	Network* clinw=malloc(sizeof(Network));
	if(NULL == nw)
	{
		perror("network accept malloc");
		return NULL;
	}
	clinw->type=nw->type;
	clinw->len = sizeof(nw->addr);
	clinw->fd=accept(nw->fd,(SP)&clinw->addr,&clinw->len);
	if(0>clinw->fd)
	{
		perror("network accept");
		free(clinw);
		return NULL;
	}
	return clinw;
}

//发送数据
int nsend(Network* nw,void* buf,uint32_t len)
{
	if(nw->type==SOCK_STREAM)
	{
		return send(nw->fd,buf,len,0);
	}
	else if(nw->type==SOCK_DGRAM)
	{
		return sendto(nw->fd,buf,len,0,(SP)&nw->addr,nw->len);
	}
	return -1;
}

//接收数据
int nrecv(Network* nw,void* buf,uint32_t len)
{
	if(nw->type==SOCK_STREAM)
	{
		return recv(nw->fd,buf,len,0);
	}
	else if(nw->type==SOCK_DGRAM)
	{
		return recvfrom(nw->fd,buf,len,0,(SP)&nw->addr,&nw->len);
	}
	return -1;
}

//关闭网络连接
void close_network(Network* nw)
{
	if(close(nw->fd))
	{
		perror("network close");
	}
	free(nw);
}
